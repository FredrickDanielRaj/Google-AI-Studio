import { GoogleGenAI, Type, Modality } from "@google/genai";
import { Character } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

async function generateCharacterImage(description: string, name: string, characterClass: string): Promise<string> {
    try {
        const imagePrompt = `A high-quality, detailed fantasy portrait of ${name}, the ${characterClass}. ${description}`;
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: {
                parts: [{ text: imagePrompt }],
            },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        });

        for (const part of response.candidates?.[0]?.content?.parts || []) {
            if (part.inlineData) {
                const base64ImageBytes: string = part.inlineData.data;
                return `data:image/png;base64,${base64ImageBytes}`;
            }
        }
        throw new Error("No image data found in response.");

    } catch (error) {
        console.error("Error generating character image:", error);
        throw new Error("Failed to generate image for a character.");
    }
}


export async function generateCharacter(): Promise<Character> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: "Generate one random fantasy character. The character must have a unique name, a class from 'Mage', 'Rogue', or 'Warrior', a one-sentence visual description, and stats for Health, Strength, Mana, and Agility, with each stat being a random integer between 50 and 100.",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: {
              type: Type.STRING,
              description: "The character's unique fantasy name."
            },
            class: {
              type: Type.STRING,
              description: "The character's class, chosen from 'Mage', 'Rogue', or 'Warrior'."
            },
            description: {
              type: Type.STRING,
              description: "A brief, one-sentence visual description of the character's appearance."
            },
            health: {
              type: Type.INTEGER,
              description: "The character's health points, from 50 to 100."
            },
            strength: {
              type: Type.INTEGER,
              description: "The character's strength stat, from 50 to 100."
            },
            mana: {
                type: Type.INTEGER,
                description: "The character's mana points, from 50 to 100."
            },
            agility: {
                type: Type.INTEGER,
                description: "The character's agility stat, from 50 to 100."
            }
          },
          required: ['name', 'class', 'description', 'health', 'strength', 'mana', 'agility']
        },
      },
    });
    
    const jsonString = response.text.trim();
    const charData = JSON.parse(jsonString) as Omit<Character, 'imageUrl'>;
    
    if (!charData.name || !charData.class || !charData.description) {
        throw new Error("Received malformed character data from API.");
    }

    const imageUrl = await generateCharacterImage(charData.description, charData.name, charData.class);
    
    return { ...charData, imageUrl };

  } catch (error) {
    console.error("Error generating character:", error);
    throw new Error("Failed to communicate with the AI model.");
  }
}

function getBase64DataFromUrl(dataUrl: string): string {
    const parts = dataUrl.split(',');
    if (parts.length === 2 && parts[0].includes('base64')) {
        return parts[1];
    }
    throw new Error("Invalid base64 data URL format");
}

export async function cartoonifyCharacter(character: Character): Promise<Character> {
    try {
        const base64ImageData = getBase64DataFromUrl(character.imageUrl);

        const imagePart = {
            inlineData: {
                mimeType: 'image/png',
                data: base64ImageData,
            },
        };
        const textPart = {
            text: 'Transform this portrait into a vibrant, stylized cartoon. Emphasize expressive features and bold outlines, like a modern animated movie character.',
        };

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: { parts: [imagePart, textPart] },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        });

        for (const part of response.candidates?.[0]?.content?.parts || []) {
            if (part.inlineData) {
                const newBase64ImageBytes: string = part.inlineData.data;
                const newImageUrl = `data:image/png;base64,${newBase64ImageBytes}`;
                return { ...character, imageUrl: newImageUrl };
            }
        }
        throw new Error("No cartoon image data found in response.");
    } catch (error) {
        console.error(`Error cartoonifying character ${character.name}:`, error);
        return character;
    }
}

export async function generateBackstory(character: Character): Promise<Character> {
    if (character.backstory) return character;

    try {
        const prompt = `Generate a short, one or two-sentence epic backstory for the fantasy character named ${character.name}, who is a ${character.class}. Use their description as inspiration: "${character.description}". The backstory should be intriguing and hint at a larger history.`;
        
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
        });

        const backstory = response.text.trim();
        
        return { ...character, backstory };
    } catch (error) {
        console.error(`Error generating backstory for ${character.name}:`, error);
        return character;
    }
}