import React from 'react';
import { Character } from '../types';
import { ShieldCheckIcon, HeartIcon, FistIcon, SparkleIcon, WindIcon } from './Icons';

interface CharacterCardProps {
  character: Character;
}

const getClassStyles = (className: string) => {
  switch (className.toLowerCase()) {
    case 'mage': return { border: 'border-blue-500', shadow: 'shadow-blue-500/40', accent: 'bg-blue-500' };
    case 'rogue': return { border: 'border-gray-500', shadow: 'shadow-gray-400/40', accent: 'bg-gray-500' };
    case 'warrior': return { border: 'border-red-600', shadow: 'shadow-red-500/40', accent: 'bg-red-600' };
    default: return { border: 'border-purple-600', shadow: 'shadow-purple-500/40', accent: 'bg-purple-600' };
  }
};

const StatBar: React.FC<{ icon: React.ReactNode; label: string; value: number; color: string }> = ({ icon, label, value, color }) => (
    <div className="flex items-center space-x-3">
        <div className={`p-1.5 rounded-md bg-stone-700/50 ${color}`}>{icon}</div>
        <div className="w-full">
            <div className="flex justify-between text-sm font-semibold text-amber-100/90 mb-1">
                <span>{label}</span>
                <span>{value}</span>
            </div>
            <div className="h-2.5 w-full rounded-full bg-stone-700/80">
                <div className={`${color} h-2.5 rounded-full`} style={{ width: `${value}%` }}></div>
            </div>
        </div>
    </div>
);

const CharacterCard: React.FC<CharacterCardProps> = ({ character }) => {
    const classStyles = getClassStyles(character.class);

  return (
    <div className={`w-full max-w-md animate-fade-in-up bg-stone-900/70 backdrop-blur-sm border-2 ${classStyles.border} p-2 rounded-2xl shadow-2xl ${classStyles.shadow}`}>
        <div className="bg-stone-800/50 rounded-lg p-6 flex flex-col space-y-4">
            <img 
                src={character.imageUrl} 
                alt={`Portrait of ${character.name}`} 
                className={`w-full h-64 object-cover rounded-lg border-2 ${classStyles.border}`} 
            />
            <div className="text-center">
                <h2 className="text-4xl font-bold text-white tracking-wider font-cinzel">{character.name}</h2>
                <div className={`mt-2 inline-flex items-center px-4 py-1 rounded-full text-lg font-medium text-white ${classStyles.accent}`}>
                    <ShieldCheckIcon className="w-5 h-5 mr-2"/>
                    {character.class}
                </div>
            </div>

            <div className="pt-4 border-t-2 border-amber-800/60 space-y-4">
                <StatBar icon={<HeartIcon className="w-5 h-5"/>} label="Health" value={character.health} color="bg-red-500"/>
                <StatBar icon={<FistIcon className="w-5 h-5"/>} label="Strength" value={character.strength} color="bg-orange-500"/>
                <StatBar icon={<SparkleIcon className="w-5 h-5"/>} label="Mana" value={character.mana} color="bg-blue-500"/>
                <StatBar icon={<WindIcon className="w-5 h-5"/>} label="Agility" value={character.agility} color="bg-green-500"/>
            </div>
            
            {character.backstory && (
                <div className="mt-2 pt-4 border-t-2 border-amber-800/60 animate-fade-in">
                    <p className="text-amber-100/80 italic text-center">
                        "{character.backstory}"
                    </p>
                </div>
            )}
        </div>
      <style>{`
        @keyframes fade-in-up {
          0% {
            opacity: 0;
            transform: translateY(20px) scale(0.98);
          }
          100% {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }
        @keyframes fade-in {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }
        .animate-fade-in-up {
          animation: fade-in-up 0.5s ease-out forwards;
        }
        .animate-fade-in {
          animation: fade-in 0.8s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default CharacterCard;